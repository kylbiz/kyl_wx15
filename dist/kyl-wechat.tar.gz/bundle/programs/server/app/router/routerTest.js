(function(){// test 微信添加按钮
// Router.route('/createMenu', function() {
// 	Meteor.call('createMenu', function (error, result) {
// 		console.log('createMenu', error, result);
// 	});
// }, {where: 'server'});

})();
