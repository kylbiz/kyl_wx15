(function(){// Router.route('/', function () {

// 	this.redirect('/main');

// });

Router.route('/', {
	name: 'main',
	waitOn: function () {
		return Meteor.subscribe('products', 'preview_all');
	},
	data: function () {
		productsPreview = [
			{title: '小白云工商注册', items: RegistrationLists.find({}, {name: true}).fetch()},
			{title: '小企财云', items: [
				{name: '银行开户', price: '200', type: 'bankRegister'},
				{name: '财务代理', price: '300-1900', type: 'finaceAgent'},
				{name: '流量记账包服务套餐', price: '300-3000', type: 'bookKeeping'}
			]},
			{title: '小企人事', items: [
				{name: '小企社保', type: 'hr'}
			]},
		];
		return {products: productsPreview};
	},
});


// 产品详情页
Router.route('/product/:productType', {
	name: 'product',
	waitOn: function () {
		Session.set('productType', this.params.productType);
		return Meteor.subscribe('products', this.params.productType);
	},
	// data: function () {
	// 	return ;
	// },
});


// 订单界面
Router.route('/order', {
	name: 'order',
});


// 个人中心
Router.route('/home');


// 订单列表
Router.route('/orderlist');


// 登录页
Router.route('/login', {
	name: 'login',
	onBeforeAction: function () {
		if (Meteor.userId()) {
			Router.go('/');
		} else {
			this.next();
		}
	}
});



// 注册页
Router.route('/register', {
  name: 'register',
  onBeforeAction: function() {
    if(Meteor.userId()) {
      Router.go('/');
    } else {
      this.next();      
    }
  }  
});


// 注销
Router.route('/logout', function() {
	Meteor.logout(function(err) {
		if (err) {
			console.log("logout fail");
		}
	});
	Router.go('/');
})

// 微信网页授权
Router.route('/oauth', {
	template: 'loading',
	onAfterAction: function () {
		if (Session.get('WeChatUser')) {
			return Router.go('/');
		}

		var query = this.request.query || {};
		Meteor.call('wxOAuth', query.code , function(error, result) {
			console.log('wxoauth back', error, result);
			if (!error && result) {
				Session.set("WeChatUser", result);
				Router.go('/');
			}
		});
	}
});


// 登陆权限控制 这里需要判断两种条件
// 微信登录帐号 
Router.onBeforeAction(function () {
	console.log("WeChatUser", Session.get('WeChatUser'));
	if (Session.get('WeChatUser')) {
		this.next();
	} else {
		// this.render('errPage');
		Router.go('/oauth');
	}
}, {except: ['receive', 'createMenu', 'oauth']});

// 开业啦帐号是否登录
Router.onBeforeAction(function () {
	console.log('loginUser');
	if (Meteor.userId()) {
		this.next();
	} else {
		this.render('login');
	}
}, {only: ['order', 'home', 'orderlist']});



// test 微信添加按钮
Router.route('/createMenu', function() {
	Meteor.call('createMenu', function (error, result) {
		console.log('createMenu', error, result);
	});
}, {where: 'server'});



// Router.route('/setSession', function () {
// 	// var obj = this.params;

// 	console.log('/setSession', this.request);

// 	// for (key in obj) {
// 	// 	Session.set(key, obj[key]);
// 	// }

// 	// console.log("WeChatUser", Session.get("WeChatUser"));

// 	this.response.end('ok');

// 	return 'fuck';
// })


})();
