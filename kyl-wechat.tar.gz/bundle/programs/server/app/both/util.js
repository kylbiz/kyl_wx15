(function(){log = console.log;

})();
