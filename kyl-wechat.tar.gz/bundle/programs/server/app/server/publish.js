(function(){/**
 * 首页需要 所有产品的名称 价格 图片
 */

Meteor.publish('products', function(project, opt) {
	opt = opt || {}
	products = {
		'register': RegistrationLists.find(opt),
		'finaceAgent': FinanceLists.find(opt),
		'bookKeeping': BookkeepingLists.find(opt),
		// 'bankRegister': BankRegister, // 需定义为collection
		'hr': AssuranceLists.find(),
	};

	if (project == 'preview_all') {
		products_preview = [];
		for (key in products) {
			products_preview.push(products[key]);
		}

		return products_preview;
	}

	return products[project];
});

})();
