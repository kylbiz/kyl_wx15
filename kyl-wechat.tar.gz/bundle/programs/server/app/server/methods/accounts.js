(function(){Meteor.methods({
	// 注册
	'UserRegistration': function(phone, password, wechat_openid) {
		var options = {
			username: phone,
			password: password,
			roles: ['customer'],
			profile: {
	            phone: phone,
	            wechat_openid: wechat_openid
	        }
		};

		var userId = Accounts.createUser(options);
		if (userId) {
			console.log("createUser ok");
			return 'OK';
		} else {
			console.log("createUser fail");
			throw new Meteor.Error("createUser fail", 'Error createUser fail');
		}
	}, 

	// 检测微信与Web账号的绑定
	'checkWeChatBind': function(wechat_openid) {
		Meteor.users.update({_id: Meteor.userId()}, {$set: {'profile.wechat_openid': wechat_openid}});
		return true;
	}
});

})();
