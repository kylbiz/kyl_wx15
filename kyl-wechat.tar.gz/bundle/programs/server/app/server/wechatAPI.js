(function(){Config = {
    // 'appID': 'wx86cab636626bb481',
    // 'appsecret': '7bc84f260ea4142b97a50be9a0579991',
    // 'token': 'keyboardcat123',

    'appID': 'wx69a414c6fd69003c',
    'appsecret': 'd4624c36b6795d1d99dcf0547af5443d',
    'token': 'keyboardcat123',

    'redirect_uri': 'http://101.200.217.6/oauth',
    
};
var wechatAPI = Meteor.npmRequire('wechat-api');
var WXAPI = new wechatAPI(Config.appID, Config.appsecret);

var OAuth = Meteor.npmRequire('wechat-oauth');
var oauthAPI = new OAuth(Config.appID, Config.appsecret);


// wechatAPI 传参 3
function getToken(callback) {
  // 传入一个获取全局token的方法
  console.log('getToken');
  var fs = Npm.require('fs');
  fs.readFile('access_token.txt', 'utf8', function (err, txt) {
    // if (err) {return callback(err);}
    if (err) {
    	callback(null, false);
    } else {
	    callback(null, JSON.parse(txt));
    }
  });
}

// wechatAPI 传参 4
function saveToken(token, callback) {
  // 请将token存储到全局，跨进程、跨机器级别的全局，比如写到数据库、redis等
  // 这样才能在cluster模式及多机情况下使用，以下为写入到文件的示例
  console.log("saveToken");
  var fs = Npm.require('fs');
  fs.writeFile('access_token.txt', JSON.stringify(token), callback);
}

// OAuth 传参 3
function getOAuthToken(callback) {

}

// OAuth 传参 4
function saveOAuthToken(token, callback) {

}



Meteor.methods({
	getFollowers: function() {
		var result = Async.runSync(function(callback) {
			WXAPI.getFollowers(callback);
		});

        if (result.error) {
            throw new Meteor.Error(result.error, 'get follower fail');
        } else {
    		return result.result;
        }
	},

    getUserInfo: function (openId) {
        var result = Async.runSync(function(callback) {
            WXAPI.getUser({openid:openId, lang: 'zh_CN'}, callback);
        });

        if (result.error) {
            throw new Meteor.Error(result.error, 'get user info fail');
        } else {
            return result.result;
        }
    },

    getFollowersInfo: function() {
        var followersInfo = Meteor.call('getFollowers');
        console.log("get follower", followersInfo);
        var usertotal = followersInfo.total;
        var usersList = followersInfo.data.openid;

        var usersInfo = [];
        for (key in usersList) {
            var result = Meteor.call('getUserInfo', usersList[key]);
            console.log("get user info", result);
            usersInfo.push(result);
        }

        return usersInfo;
    },

    wxOAuth: function (code) {

        if (!code) {
            console.log('wxOAuth get code');
            var wxOAuthUrl = oauthAPI.getAuthorizeURL(Config.redirect_uri, 'KYLBIZ', 'snsapi_base');
            // 获取 code
            var ret =  HTTP.get(wxOAuthUrl);
            console.log('get code ret', ret);
            return false;
        } else {
            console.log('wxOAuth get openid');
            var result = Async.runSync(function(callback) {
                oauthAPI.getAccessToken(code, callback);
            });

            if (result.error) {
                throw new Meteor.Error(result.error, 'get oauth access_token fail');
            } else {
                console.log("get oauth access_token ", result.result);
                return result.result.data.openid;
            }
        }
        



        // Config.appID, Config.appsecret
        // var  = 
        // var wxOAuthUrl = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=' + Config.appID + '&redirect_uri=' + encodeURI(Config.redirect_uri) + '&response_type=code&scope=snsapi_base&state=STATE#wechat_redirect'


        // var code = '';
        // var wxWebToken = 'https://api.weixin.qq.com/sns/oauth2/access_token?appid=' + Config.appID + '&secret=' + Config.appsecret + '&code=' + code + '&grant_type=authorization_code';
    }


});


Meteor.methods({
    // 测试 - 创建菜单
    createMenu: function () {
        var menu = {
            "button":[
                {
                    "type":"click",
                    "name":"开",
                    "key":"OPEN"
                },
                {
                    "name":"业",
                    "sub_button":[
                        {
                            "type":"view",
                            "name":"产品中心",
                            "url":"http://101.200.217.6/"
                        },
                        {
                            "type":"click",
                            "name":"赞一下我们",
                            "key":"V1001_GOOD"
                        }
                    ]
                },
                {
                    "type": "pic_sysphoto",
                    "name": "啦",
                    "key": "SEND_PICTURE"
                }
            ]
        };

        var result = Async.runSync(function(callback) {
            WXAPI.createMenu(menu, callback);
        });

        if (result.error) {
            throw new Meteor.Error(result.error, 'create menu fail');
        } else {
            return result.result;
        }
    }
});

})();
